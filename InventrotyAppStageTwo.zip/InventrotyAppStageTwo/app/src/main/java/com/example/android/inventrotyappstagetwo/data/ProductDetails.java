package com.example.android.inventrotyappstagetwo.data;

import android.provider.BaseColumns;

public class ProductDetails {

    public ProductDetails() {
    }

    public static final class StockEntry implements BaseColumns {

        public static final String TABLE_NAME = "stock";

        public static final String _ID = BaseColumns._ID;
        public static final String COLUMN_NAME = "name";
        public static final String COLUMN_PRICE = "price";
        public static final String COLUMN_QUANTITY = "quantity";
        public static final String COLUMN_SUPPLIER_NAME = "supplier_name";
        public static final String COLUMN_SUPPLIER_PHONE = "supplier_phone";
        public static final String COLUMN_SUPPLIER_EMAIL = "supplier_email";
        public static final String COLUMN_IMAGE = "image";

        public static final String CREATE_TABLE_STOCK = "CREATE TABLE " +
                ProductDetails.StockEntry.TABLE_NAME + "(" +
                ProductDetails.StockEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                ProductDetails.StockEntry.COLUMN_NAME + " TEXT NOT NULL," +
                ProductDetails.StockEntry.COLUMN_PRICE + " TEXT NOT NULL," +
                ProductDetails.StockEntry.COLUMN_QUANTITY + " INTEGER NOT NULL DEFAULT 0," +
                ProductDetails.StockEntry.COLUMN_SUPPLIER_NAME + " TEXT NOT NULL," +
                ProductDetails.StockEntry.COLUMN_SUPPLIER_PHONE + " TEXT NOT NULL," +
                ProductDetails.StockEntry.COLUMN_SUPPLIER_EMAIL + " TEXT NOT NULL," +
                StockEntry.COLUMN_IMAGE + " TEXT NOT NULL" + ");";
    }
}
